package com.mindera.school;

public class Arrays {
    /**
     * Create a function (getNegativeNumbers) that takes an array of integers and returns the number of elements in the
     * array that are negative numbers.
     */
    public int getNegativeNumbers(int[] array) {
        return 0;
    }

    /**
     * Create a function (getNumberOfTimes) that takes an array of integers and an integer and returns the number of
     * times that number appears in the array.
     */
    public int getNumberOfTimes(int[] array, int number) {
        return 0;
    }

    /**
     * Create a function (getBooleanArray) that takes an array of integers and returns an array of booleans.
     * If the number is positive it will be replaced by true.
     * If it is negative or zero by false.
     */
    public boolean[] getBooleanArray(int[] array) {
        return null;
    }

    /**
     * Create a function (getLargestNumber) that takes an array of integers and returns the position of the largest
     * number.
     */
    public int getLargestNumber(int[] array) {
        return 0;
    }

    /**
     * Create a function (getOddEvenArray) that takes an array of integers and replaces the odd numbers with -1 and the
     * even numbers with 1.
     */
    public int[] getOddEvenArray(int[] array) {
        return null;
    }

    /**
     * Create a function (sumAllElements) that takes an array of integers and returns the sum of all values
     */
    public int sumAllElements(int[] array) {
        return 0;
    }

    /**
     * Create a function (removeElement) that takes an array of integers and a number and removes it from the array;
     */
    public int[] removeElement(int[] array, int number) {
        return null;
    }

    /**
     * Create a function (orderArray) that takes an array of integers and returns the array ordered from largest to
     * smallest.
     */
    public int[] orderArray(int[] array) {
        return null;
    }
}
