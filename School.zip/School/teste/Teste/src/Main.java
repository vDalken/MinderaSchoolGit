public class Main {

    public static void main(String[] args) {
        int number = 10;
        //ou
        Integer numberIn = 10;


        boolean isBigger = false;
        //ou
        Boolean isBiggerF = false;

        double numberDouble = 10.9;
        //
        Double num = 10.9;

        char char1 = '1';
        //ou
        Character character = '1';

        String name = "Pedro";
    }
}